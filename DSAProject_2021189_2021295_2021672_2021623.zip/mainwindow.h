#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QWidget>
class MainWindow : public QWidget
{
    Q_OBJECT
public:
MainWindow();

signals:


};

#endif // MAINWINDOW_H
